import React from 'react'

function Footer () {
  return (
    <footer className="footer d-flex justify-content-center align-itmes-center">
        <p>Create By @ Phailin Sarapimpa</p>
    </footer>
  )
}

export default Footer