import React from 'react'

function ShowData() {
  return (
    <div>ShowData</div>
  )
}

export default ShowData