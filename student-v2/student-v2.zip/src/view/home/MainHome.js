import React from 'react'

function MainHome() {
  return (
    <div>MainHome</div>
  )
}

export default MainHome